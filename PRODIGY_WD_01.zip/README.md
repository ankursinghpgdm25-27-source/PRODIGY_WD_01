# PRODIGY_WD_01 — Responsive Landing Page (Task 1)

**What this is:**  
A clean, responsive landing page (HTML/CSS/JS) built as Task 1 for the PRODIGY Web Development track.

## Files included
- `index.html` — main page
- `style.css` — styles
- `script.js` — small JS for navbar and mobile menu
- `README.md` — this file
- `.gitignore`

## Features
- Fixed navbar that changes color on scroll
- Mobile-friendly hamburger menu
- Hero section with gradient background and CTA
- About, Services, Contact sections and Footer
- Responsive layout (desktop/tablet/mobile)

## Run locally
1. Open `index.html` in your browser (double-click).  
2. Or serve via a tiny static server (recommended for hrefs and testing):
   - `npx http-server` (install `http-server` if needed)
   - or `python -m http.server 8080` and open `http://localhost:8080/`

## How to submit (GitHub + LinkedIn) — condensed steps
1. Create a **new public repo** on GitHub with name: `PRODIGY_WD_01`  
2. Upload these files (either drag-and-drop via GitHub UI or push via `git` CLI).  
3. (Optional) Enable **GitHub Pages**: Repository Settings → Pages → Branch `main` → Save → use the provided URL for the live demo.  
4. Make a LinkedIn post describing the task, add screenshots or a short video, and include the repo link + live demo link.  
5. Fill the Task Submission Form (you'll receive it mid-internship) and paste your **repo link** and **LinkedIn post link**.

## Suggested commit message
```
Task 1: Responsive Landing Page — add index, styles, and scripts
```

## Checklist before submission
- [ ] Repo name follows `PRODIGY_TrackCode_TaskNumber` (example: `PRODIGY_WD_01`)
- [ ] Repo is **public**
- [ ] README explains how to run and what you built
- [ ] Add 1-2 screenshots in the repo (optional but recommended)
- [ ] LinkedIn post created with repo & demo links
- [ ] Paste repo + LinkedIn post links in the Task Submission Form

## LinkedIn post template (short)
**Title:** Built a responsive landing page — Task 1 (PRODIGY Web Dev)  
**Body:** I built a responsive landing page with a fixed navbar, mobile menu, hero, services, and contact form. Learned: responsive layouts, mobile navigation patterns, and accessibility basics. Check out the code: `https://github.com/YOUR_USERNAME/PRODIGY_WD_01`  
**Hashtags:** #PRODIGY #WebDevelopment #Portfolio #Task1

Good luck — and shout if you want me to draft the exact LinkedIn text and caption in Hindi/English, or create screenshots for the post.
